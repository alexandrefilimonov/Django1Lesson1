from django.shortcuts import render

# Create your views here.
def main(request):
    return render(request, 'mainapp/index.html') 

def products(request):
    return render(request, 'mainapp/products.html') 

def contacts(request):
    return render(request, 'mainapp/contacts.html') 
	
def item1(request):
    return render(request, 'mainapp/item1.html') 

def item2(request):
    return render(request, 'mainapp/item2.html') 

def item3(request):
    return render(request, 'mainapp/item3.html') 

def item4(request):
    return render(request, 'mainapp/item4.html') 

def item5(request):
    return render(request, 'mainapp/item5.html') 

